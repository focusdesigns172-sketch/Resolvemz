# 🇲🇿 ResolveMZ

App de Matemática e Física para estudantes moçambicanos.

## Como colocar online (Vercel)

1. Faz upload destes ficheiros no GitHub
2. Vai a vercel.com e liga ao repositório
3. Em "Environment Variables" adiciona:
   - Nome: `REACT_APP_GROQ_API_KEY`
   - Valor: a tua chave do Groq (começa com gsk_...)
4. Clica Deploy!

## Funcionalidades
- Resolver exercícios de Matemática e Física com IA
- Passo a passo detalhado
- Quiz de aprendizado
- Ranking de melhores alunos
- Histórico de exercícios
- Pagamento via M-Pesa e e-Mola
- Funciona como app no telemóvel (PWA)
